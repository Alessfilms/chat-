import subprocess, re, json, numpy as np
AUD='/home/claude/SCRIPTTER/audio/narracao_original.mp3'
log=subprocess.run(['ffmpeg','-hide_banner','-i',AUD,'-af','silencedetect=n=-35dB:d=0.35','-f','null','-'],capture_output=True,text=True).stderr
ss=[float(x) for x in re.findall(r'silence_start: ([\d.]+)',log)]
se=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',log)]
raw=subprocess.run(['ffmpeg','-v','error','-i',AUD,'-f','f32le','-ac','1','-ar','16000','-'],capture_output=True).stdout
x=np.frombuffer(raw,np.float32); sr=16000; dur=len(x)/sr
starts=[0.0]+se; ends=ss+[dur]
segs=[]
for i,(a,b) in enumerate(zip(starts,ends)):
    c=x[int(a*sr):int(b*sr)]; rms=float(np.sqrt((c**2).mean())); pk=float(np.abs(c).max())
    segs.append(dict(id=f'F{i+1:02d}',start=round(a,3),end=round(b,3),dur=round(b-a,3),rms_db=round(20*np.log10(rms+1e-9),1),peak_db=round(20*np.log10(pk+1e-9),1)))
med=np.median([s['rms_db'] for s in segs])
for s in segs: s['intensidade']='forte' if s['rms_db']>med+1.5 else ('suave' if s['rms_db']<med-1.5 else 'media')
pauses=[dict(start=round(a,3),end=round(b,3),dur=round(b-a,3)) for a,b in zip(ss,se)]
scenes=[('S01','Os 200 historiadores',1,2),('S02','O reino proibido',3,4),('S03','A ordem do Rei',5,6),('S04','Os dois inventores',7,9),
('S05','O nascimento da Scriptter',10,12),('S06','Os guardas reais',13,14),('S07','O desafio',15,19),('S08','O pedido de ajuda',20,21),
('S09','A mensagem viaja',22,23),('S10','A chegada dos historiadores',24,26),('S11','O convite',27,len(segs))]
sc=[]
for k,(sid,name,f0,f1) in enumerate(scenes):
    a=0.0 if k==0 else segs[f0-2]['end']+ (segs[f0-1]['start']-segs[f0-2]['end'])/2  # cut in middle of pause
    b=dur+2.5 if k==len(scenes)-1 else segs[f1-1]['end']+(segs[f1]['start']-segs[f1-1]['end'])/2
    sc.append(dict(id=sid,nome=name,frases=[segs[i]['id'] for i in range(f0-1,f1)],start=round(a,3),end=round(b,3),
      frame_in=int(round(a*24)),frame_out=int(round(b*24)),mapeamento='estimado — confirmar com o texto da narração'))
out=dict(audio='audio/narracao_original.mp3',duracao=round(dur,3),fps=24,total_frames=int(round((dur+2.5)*24)),
 nota='Narração intacta (sem cortes/aceleração). Cauda final de 2,5 s só com ambiência para o CTA. Frases detectadas por silêncio (-35 dB, 0,35 s).',
 frases=segs,pausas=pauses,cenas=sc)
json.dump(out,open('/home/claude/SCRIPTTER/timeline.json','w'),ensure_ascii=False,indent=1)
for s in sc: print(s['id'],s['start'],s['end'],s['frases'])
print('fortes',[s['id'] for s in segs if s['intensidade']=='forte'])
