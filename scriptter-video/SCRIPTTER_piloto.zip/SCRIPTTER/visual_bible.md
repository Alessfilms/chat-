# Scriptter: O Reino dos Historiadores — Bíblia Visual

Referência-mestre: `references/reino_referencia.png` (941 × 1671). Ela define a linguagem de todo o episódio.

## 1. Linguagem
- Pixel art medieval isométrica, câmera elevada (≈ 30–40° de mergulho), estilo RPG indie premium.
- Contorno escuro (quase preto, `#0c0a0f` / `#111310`) em tudo que é objeto; sem antialiasing suave.
- Densidade alta de detalhe: cada plano tem pelo menos 3 elementos vivos (água, fogo, bandeira, fumaça, pássaros, moradores).
- Proibido: anime liso, pintura digital, vetor, 3D realista, hologramas, blur gaussiano em primeiro plano.

## 2. Grade de pixels e câmera
- Grade nativa = a da referência. Janela de câmera de **540 × 960 px de referência**, ampliada **2× nearest-neighbor** → 1080 × 1920.
- Câmera move-se só em **pixels inteiros** (sem zoom digital, sem rotação, sem reamostragem fracionária) → pixels sempre nítidos.
- Profundidade por **parallax 2.5D**: camada de copa em primeiro plano (pixel 3×, mais grosso = mais perto, velocidade 1,8× da câmera), névoa com dithering Bayer (1,2×), cenário (1×), céu/montanhas (0,6× quando houver recorte).
- Movimentos com easing suave (smoothstep / ease-in-out); nada brusco.

## 3. Luz e cor
- Paleta-mestre de 32 cores extraída da referência: `references/paleta_32.png`.
- Luz-chave: dourado de pôr do sol vindo do alto-direita (`#f8bb4a`, `#fae177`, `#f69e45`).
- Sombras: violeta/vinho (`#291616`, `#3e2222`, `#6b566a`), nunca cinza neutro.
- Acentos: roxo dos estandartes e flores, dourado da pena; água em ciano-turquesa.
- Fontes de luz quentes (fogueira, tochas, janelas) com oscilação de 6–12% e brilho em raio.

## 4. Elementos-símbolo
- Estandarte roxo com pena dourada em louros: aparece em todo plano do reino.
- Pergaminhos físicos impressos; nada de holograma.

## 5. Personagens (model sheets ainda não estão no projeto — pasta `modelsheets/` vazia)
| Personagem | Traços fixos |
|---|---|
| Inventor 01 | cabelo castanho, óculos de inventor sobre a cabeça, cachecol vermelho, roupa de aventureiro |
| Inventor 02 | cabelo escuro encaracolado, óculos redondos, camisa clara, colete medieval |
| Rei | idoso, cabelo e barba grisalhos, coroa dourada, vestes roxas, capa com pele clara |
| Máquina Scriptter | impressora steampunk roxo + dourado, engrenagens de bronze, cristal violeta, rolos, selo de pena dourada na frente |
| Moradores/historiadores | ~38 px de altura na grade da referência, capuz + capa (roxo, marrom, verde-musgo, vinho), carregam livro ou pergaminho |

Escala de personagem: igual aos dois moradores já existentes na referência (≈ 20 × 40 px).

## 6. Mapa da referência (coordenadas em px da referência)
- Castelo: portão (260, 340); estandarte do portão (238–282, 235–320).
- Praça/fogueira: (470, 735). Forja: estandarte (555–622, 555–665), chaminé (565, 455).
- Casa à direita: chaminé com fumaça (856, 345).
- Ponte: estandartes (345–420, 1030–1195) e (835–897, 855–990).
- Cachoeiras: superior (605–735, 960–1210), inferior (560–640, 1260–1410). Rio: (150–650, 1380–1590). Moinho: roda (690, 1360).

## 7. Som
Sem música, sem exceção. Só narração original + SFX + ambiência, todos sintetizados neste projeto (originais) ou de biblioteca licenciada.
