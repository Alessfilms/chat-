# SCRIPTTER — O Reino dos Historiadores

Status: **cena piloto S01 pronta para aprovação.** Demais cenas pendentes.

- `timeline.json` — 29 frases da narração (98,43 s) com início/fim, pausas, intensidade e 11 cenas (mapeamento frase→cena estimado; confirmar com o texto).
- `storyboard.json` — decupagem das 11 cenas (plano, ação, transição, SFX).
- `visual_bible.md` — regras visuais, paleta (`references/paleta_32.png`), mapa da referência.
- `render_manifest.json` — status por cena.

Reproduzir o piloto:
```
python3 scenes/s01_pilot.py          # vídeo mudo + quadros-chave + cues de som
python3 sound_effects/sfx_s01.py     # SFX sintetizados + mix + MP4 final
```
Arquivos originais preservados em `references/` e `audio/` (cópias; nada foi modificado).
