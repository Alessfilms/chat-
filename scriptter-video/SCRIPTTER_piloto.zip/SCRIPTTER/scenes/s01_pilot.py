"""Cena 01 — Os 200 historiadores (piloto). Pipeline 2.5D pixel art.
Renderiza frames 1080x1920 (janela 540x960 da referência, ampliada 2x nearest) e salva
quadros-chave + vídeo mudo + cue list para o som.
Uso: python3 scenes/s01_pilot.py
"""
import json, os, subprocess, sys
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REF = np.asarray(Image.open(f'{ROOT}/references/reino_referencia.png').convert('RGB')).astype(np.float32)
H, W = REF.shape[:2]
TL = json.load(open(f'{ROOT}/timeline.json'))
SC = [s for s in TL['cenas'] if s['id'] == 'S01'][0]
FPS = 24
N = SC['frame_out'] - SC['frame_in']
VW, VH = 540, 960
UP = 2
OUT = f'{ROOT}/renders/S01'
os.makedirs(f'{OUT}/keyframes', exist_ok=True)
rng = np.random.default_rng(7)

BAYER = (np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) + .5) / 16


def ease(t):
    t = np.clip(t, 0, 1); return t * t * t * (t * (t * 6 - 15) + 10)


# ---------------- câmera (pixels inteiros) ----------------
CAM0, CAM1 = (330, 711), (200, 390)
def cam(f):
    e = ease(f / (N - 1))
    return int(round(CAM0[0] + (CAM1[0] - CAM0[0]) * e)), int(round(CAM0[1] + (CAM1[1] - CAM0[1]) * e))

# ---------------- máscaras da referência ----------------
lum = REF.mean(2)
r, g, b = REF[..., 0], REF[..., 1], REF[..., 2]

def boxmask(x0, y0, x1, y1):
    m = np.zeros((H, W), bool); m[y0:y1, x0:x1] = True; return m

falls = boxmask(605, 960, 740, 1215) | boxmask(555, 1255, 645, 1415)
water_fall = falls & (lum > 120) & (b > r * 0.95)
river = boxmask(140, 1370, 660, 1600) & (b > r + 10) & (g > r)
fire_box = boxmask(440, 680, 505, 770)
fire_hot = fire_box & (r > 235) & (g > 150) & (b < 150)
_fy, _fx = np.nonzero(fire_hot)
FIRE_W = np.clip(1 - np.hypot(_fx - 472, (_fy - 728) * 1.2) / 34, 0, 1)[:, None]
windows = (r > 220) & (g > 150) & (b < 120) & ~fire_box
WIN_PH = (np.nonzero(windows)[1] // 6) % 7

# textura de espuma: ruído 1D por coluna, rolando para baixo
foam = rng.random((H + 64, W)) ** 2
for _ in range(2):
    foam = (foam + np.roll(foam, 1, 0) + np.roll(foam, 2, 0)) / 3

BANNERS = [(236, 232, 286, 324, 1.0), (552, 552, 626, 668, 1.5), (296, 572, 333, 643, 1.2),
           (750, 628, 783, 695, 1.2), (852, 704, 881, 763, 1.1), (343, 1028, 423, 1198, 1.8),
           (832, 852, 900, 993, 1.6)]

# ---------------- sprites ----------------
OUTL = (14, 10, 16)
SKIN = (222, 170, 126)
CLOAKS = [((112, 52, 128), (78, 34, 92)), ((122, 82, 52), (84, 54, 34)), ((84, 98, 56), (56, 66, 36)),
          ((128, 44, 48), (88, 28, 32)), ((92, 64, 110), (62, 42, 76))]
BOOK = [(196, 160, 96), (232, 214, 170), (150, 60, 50)]
BODY = ["....CCCC....", "...ChhCCc...", "..ChSSSSCc..", "..CSESSESc..", "..CSSSSsSc..", "...cSSssc...",
        "..CCcCCcCC..", ".ChCCCCCCCc.", ".ChCCCCCCCcc", ".ChhBBBBCCcc", ".CSbBBBBSCcc", ".CCbbbbbCCcc",
        ".CCCTTTTCCc.", ".ChCCCCCCCc.", ".ChCCCCCcCc.", ".CCCCCCcCCc.", ".CCCCCCcCCc.", "..CCCCcCCc..",
        "..CCCCcCcc..", "..cCCCcCcc.."]
LEGS = [["...L...L....", "...L...L....", "..FF...FF..."], ["...L..L.....", "...L..L.....", "..FF.FF....."],
        ["..L....L....", "..L....L....", ".FF....FF..."], ["....LL......", "....LL......", "...FFFF....."]]
def villager(ci, bi, frame, flip):
    rows = BODY + LEGS[frame % 4]
    c1, c2 = CLOAKS[ci]
    hl = tuple(min(255, int(v * 1.35 + 18)) for v in c1)
    bk = BOOK[bi]; bks = tuple(int(v * .7) for v in bk)
    cmap = {'C': c1, 'c': c2, 'h': hl, 'S': SKIN, 's': (176, 120, 90), 'E': (30, 20, 24), 'B': bk, 'b': bks,
            'T': (214, 168, 64), 'L': (52, 36, 30), 'F': (34, 24, 20)}
    h, w = len(rows) + 2, 14
    a = np.zeros((h, w, 4), np.uint8)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in cmap: a[y + 1, x + 1, :3] = cmap[ch]; a[y + 1, x + 1, 3] = 255
    al = a[..., 3] > 0
    ring = np.zeros_like(al)
    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        ring |= np.roll(np.roll(al, dy, 0), dx, 1)
    ring &= ~al
    a[ring, :3] = OUTL; a[ring, 3] = 255
    if frame % 2 == 1:  # bob
        a = np.roll(a, -1, 0)
    if flip: a = a[:, ::-1]
    return a.repeat(2, 0).repeat(2, 1)  # escala da referência (~2px por pixel de sprite)

# moradores: caminhos isométricos (ref px), ida e volta
WALK = [((388, 650), (452, 684)), ((540, 800), (612, 764)), ((352, 870), (420, 834)), ((290, 760), (230, 790)),
        ((600, 712), (664, 744)), ((470, 852), (536, 886)), ((410, 948), (350, 980)), ((640, 830), (700, 860))]
WALKERS = [dict(p=p, ci=i % 5, bi=i % 3, ph=rng.random(), sp=0.022 + 0.01 * rng.random()) for i, p in enumerate(WALK)]

def paste(canvas, spr, x, y):
    h, w = spr.shape[:2]; x, y = int(x - w / 2), int(y - h)
    x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, canvas.shape[1]), min(y + h, canvas.shape[0])
    if x1 <= x0 or y1 <= y0: return
    s = spr[y0 - y:y1 - y, x0 - x:x1 - x]; m = s[..., 3:4] / 255.
    canvas[y0:y1, x0:x1] = canvas[y0:y1, x0:x1] * (1 - m) + s[..., :3] * m

def shadow(canvas, x, y, w=14):
    yy, xx = np.ogrid[-3:4, -w // 2:w // 2 + 1]
    m = (xx / (w / 2)) ** 2 + (yy / 3) ** 2 <= 1
    y0, x0 = int(y) - 3, int(x) - w // 2
    reg = canvas[y0:y0 + 7, x0:x0 + w + 1]
    if reg.shape[:2] == m.shape: reg[m] *= 0.62

BIRD = [["O.....O", ".O...O.", "..OOO.."], ["OO...OO", "..OOO..", "......."], [".......", "OOOOOOO", "..O.O.."]]
def bird(frame):
    rows = BIRD[frame % 3]; a = np.zeros((3, 7, 4), np.uint8)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == 'O': a[y, x] = (40, 22, 38, 255)
    return a.repeat(2, 0).repeat(2, 1)

FLOCK_T0 = 2.2  # s
FLOCK = [dict(dx=i * 22 + rng.integers(0, 10), dy=(i % 2) * 14 + i * 4, ph=i) for i in range(5)]

# ---------------- primeiro plano: copa (parallax 1.8x) ----------------
CAN_TOP = 1300   # faixa acima da tela (px)
def make_canopy():
    """Copa em primeiro plano, desenhada na grade 3x (mais grossa = mais perto), em sombra com borda dourada."""
    P = 3; lw, lh = VW // P, (VH + CAN_TOP) // P
    can = np.zeros((lh, lw, 4), np.float32)
    greens = [(10, 18, 10), (22, 38, 18), (44, 66, 26), (88, 104, 34), (156, 146, 54), (210, 186, 80)]
    purples = [(24, 10, 28), (58, 26, 68), (108, 56, 120), (166, 102, 170), (210, 150, 206)]
    r2 = np.random.default_rng(11)
    yy, xx = np.mgrid[0:lh, 0:lw]
    clusters = []
    for _ in range(38):
        side = r2.random()
        if side < .42: x = r2.integers(-25, 45)
        elif side < .84: x = r2.integers(135, 205)
        else: x = r2.integers(40, 140)
        y = r2.integers(-250 // P, (VH + 60) // P) if side < .84 else r2.integers(int(VH * .62) // P, (VH + 60) // P)
        clusters.append((x, y + CAN_TOP // P, r2.integers(14, 30), purples if r2.random() < .15 else greens))
    clusters.sort(key=lambda c: c[1])
    for cx, cy, rad, pal in clusters:
        n = int(rad * 2.2)
        for k in range(n):  # muitas folhinhas arredondadas
            ang = r2.random() * 6.283; dist = rad * np.sqrt(r2.random())
            ox, oy = dist * np.cos(ang), dist * np.sin(ang) * .8
            rr = 2.2 + 3.2 * r2.random()
            x0, x1 = int(max(cx + ox - rr - 1, 0)), int(min(cx + ox + rr + 2, lw))
            y0, y1 = int(max(cy + oy - rr - 1, 0)), int(min(cy + oy + rr + 2, lh))
            if x1 <= x0 or y1 <= y0: continue
            sx, sy = xx[y0:y1, x0:x1] - (cx + ox), yy[y0:y1, x0:x1] - (cy + oy)
            d = (sx ** 2 + sy ** 2) / rr ** 2
            body = d < 1
            # luz: alto-direita da folha + quanto mais no alto-direita do tufo, mais claro
            lit = .5 - (sy - sx * .7) / rr * .35 + (-(oy) + ox * .5) / rad * .25
            lit = lit + (BAYER[yy[y0:y1, x0:x1] % 4, xx[y0:y1, x0:x1] % 4] - .5) * .25
            idx = np.clip((lit * (len(pal) - 1.2)).astype(int), 0, len(pal) - 1)
            col = np.array(pal, np.float32)[idx]
            reg = can[y0:y1, x0:x1]
            reg[body, :3] = col[body]; reg[body, 3] = 1
            rim = body & (d > .7) & (sy > 0)           # sombra entre folhas
            reg[rim, :3] = np.array(pal[0], np.float32)
    al = can[..., 3] > 0
    ring = np.zeros_like(al)
    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)): ring |= np.roll(np.roll(al, dy, 0), dx, 1)
    ring &= ~al
    can[ring, :3] = OUTL; can[ring, 3] = 1
    return can.repeat(P, 0).repeat(P, 1)

CANOPY = make_canopy()

# ---------------- render ----------------
cues = dict(birds=[], waterfall_vis=[], fire_vis=[], fire_pan=[], fall_pan=[], canopy=[])
def render(f):
    t = f / FPS
    img = REF.copy()
    # água: espuma rolando
    sh = int(f * 5) % 64
    fm = foam[64 - sh:64 - sh + H]
    wf = water_fall
    hi = wf & (fm > .55); lo = wf & (fm < .18)
    img[hi] = img[hi] * .35 + np.array([236, 250, 255]) * .65
    img[lo] = img[lo] * .78 + np.array([60, 140, 170]) * .22
    # rio: brilhos que descem o fluxo
    sp = np.roll(np.roll(foam[:H], int(f * 1.2), 1), int(f * .5), 0)
    rv = river & (sp > .82)
    img[rv] = img[rv] * .45 + np.array([200, 245, 250]) * .55
    # fogo
    fl = .88 + .12 * np.sin(t * 17) * np.sin(t * 7.3 + 1) + .06 * rng.standard_normal()
    img[fire_hot] = np.clip(img[fire_hot] * (1 + (fl - 1) * FIRE_W), 0, 255)
    yy, xx = np.ogrid[0:H, 0:W]
    # glow da fogueira (só na região próxima)
    y0, y1, x0, x1 = 600, 880, 340, 610
    d = np.sqrt(((xx[:, x0:x1] - 472) / 1.0) ** 2 + ((yy[y0:y1] - 735) / .7) ** 2)
    glow = np.clip(1 - d / 120, 0, 1) ** 2 * (.16 + .07 * fl)
    q = np.floor((glow + BAYER[(yy[y0:y1] % 4), (xx[:, x0:x1] % 4)] * .05) * 20) / 20  # luz quantizada
    img[y0:y1, x0:x1] += q[..., None] * np.array([255, 150, 60])
    # janelas tremeluzem levemente
    img[windows] *= (.96 + .04 * np.sin(t * 3 + WIN_PH))[:, None]
    # brasas
    for k in range(10):
        life = (t * .9 + k / 10) % 1
        ex = 472 + 10 * np.sin(k * 3.1 + t * 2) + (k - 5) * 2; ey = 725 - life * 70
        if life < .9:
            c = np.array([255, 200 - life * 120, 60]) * (1 - life * .5)
            img[int(ey):int(ey) + 2, int(ex):int(ex) + 2] = c
    # fumaça da forja (565,455) e casa (856,345)
    for (sx, sy) in ((566, 452), (856, 342)):
        for k in range(7):
            life = (t * .22 + k / 7) % 1
            px = sx + life * 38 + 5 * np.sin(life * 6 + k); py = sy - life * 120
            rad = 4 + life * 13; a = .55 * (1 - life)
            ys, xs = slice(int(py - rad), int(py + rad)), slice(int(px - rad), int(px + rad))
            sub = img[ys, xs]
            if sub.size == 0: continue
            gy, gx = np.mgrid[ys, xs]
            m = ((gx - px) ** 2 + (gy - py) ** 2) / rad ** 2 < 1
            m &= BAYER[gy % 4, gx % 4] < a
            sub[m] = sub[m] * .35 + np.array([200, 190, 205]) * .65
    # estandartes ao vento (deslocamento por linha, ancorados no topo)
    for (bx0, by0, bx1, by1, amp) in BANNERS:
        reg = img[by0:by1, bx0 - 3:bx1 + 3].copy()
        for row in range(by1 - by0):
            k = row / (by1 - by0)
            s = int(round(amp * k * np.sin(t * 3.2 - row * .12 + bx0)))
            if s: img[by0 + row, bx0 - 3:bx1 + 3] = np.roll(reg[row], s, 0)
    # moradores (ordenados por profundidade y)
    sprites = []
    for wk in WALKERS:
        (ax, ay), (bx, by) = wk['p']
        u = (t * wk['sp'] * 10 + wk['ph']) % 2; fwd = u < 1; v = u if fwd else 2 - u
        x, y = ax + (bx - ax) * v, ay + (by - ay) * v
        flip = (bx < ax) == fwd
        sprites.append((y, x, villager(wk['ci'], wk['bi'], int(t * 8 + wk['ph'] * 4), flip)))
    for y, x, s in sorted(sprites, key=lambda q: q[0]):
        shadow(img, x, y); paste(img, s, x, y)

    cx, cy = cam(f)
    view = img[cy:cy + VH, cx:cx + VW].copy()

    # pássaros (espaço de tela)
    tb = t - FLOCK_T0
    if 0 <= tb <= 6:
        for i, bd in enumerate(FLOCK):
            bx = VW + 20 - tb * 110 + bd['dx']; by = 260 + bd['dy'] - tb * 14 + 4 * np.sin(tb * 3 + i)
            paste(view, bird(int(t * 10) + bd['ph']), bx, by)
        if f % 12 == 0: cues['birds'].append((t, float(np.clip((VW - tb * 110) / VW, 0, 1))))
    # névoa dourado-violeta com dithering (1.2x)
    mist_y = (cy - CAM0[1]) * -0.2
    yy2, xx2 = np.mgrid[0:VH, 0:VW]
    band = .5 + .5 * np.sin(yy2 * .018 + xx2 * .006 + t * .35 + mist_y * .02) * np.sin(xx2 * .011 - t * .2)
    dens = np.clip(band * (.42 - .40 * ease(f / (N * .6))), 0, 1)
    lvl = np.floor(dens[::2, ::2] * 5) / 5 * .5          # 3 níveis de névoa, sem dithering
    lvl = lvl.repeat(2, 0).repeat(2, 1)[:VH, :VW, None]
    tint = np.array([236, 196, 160]) * (1 - yy2[..., None] / VH) + np.array([170, 140, 190]) * (yy2[..., None] / VH)
    view = view * (1 - lvl) + tint * lvl
    # partículas: folhas/pétalas ao vento
    for k in range(14):
        px = (k * 97 + t * (38 + k * 3)) % (VW + 40) - 20
        py = (k * 173 + t * (22 + k % 5 * 6) + 30 * np.sin(t + k)) % VH
        col = (150, 84, 160) if k % 3 == 0 else (196, 180, 70)
        view[int(py):int(py) + 2, int(px):int(px) + 2 + (int(t * 6 + k) % 2)] = col
    # copa em primeiro plano: abre por completo até ~5,5 s (parallax rápido)
    off = int(ease(t / 5.5) * (VH + 420))
    sway = int(round(3 * np.sin(t * 1.1))) * 3
    top = CAN_TOP - off
    if top + VH > 0:
        cs = np.roll(CANOPY[max(top, 0):top + VH], sway, 1)
        dy0 = max(0, -top); hh = min(VH - dy0, cs.shape[0])
        a = cs[:hh, :, 3:4]
        view[dy0:dy0 + hh] = view[dy0:dy0 + hh] * (1 - a) + cs[:hh, :, :3] * a
        cues['canopy'].append((t, float(a.mean())))
    else:
        cues['canopy'].append((t, 0.0))
    # cues de som
    wf_screen = (650 - cx) / VW, (1180 - cy) / VH
    cues['waterfall_vis'].append((t, float(np.clip(1.25 - abs(wf_screen[1] - .5) * 1.6, 0, 1))))
    cues['fall_pan'].append((t, float(np.clip(wf_screen[0] * 2 - 1, -1, 1))))
    fs = (472 - cx) / VW, (735 - cy) / VH
    cues['fire_vis'].append((t, float(np.clip(1.2 - abs(fs[1] - .5) * 1.8, 0, 1))))
    cues['fire_pan'].append((t, float(np.clip(fs[0] * 2 - 1, -1, 1))))

    view = np.clip(view, 0, 255).astype(np.uint8)
    return view.repeat(UP, 0).repeat(UP, 1)


if __name__ == '__main__':
    only = [int(a) for a in sys.argv[1:]]
    if only:
        for f in only: Image.fromarray(render(f)).save(f'{OUT}/keyframes/s01_f{f:04d}.png')
        sys.exit()
    ff = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{VW*UP}x{VH*UP}',
                           '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-tune', 'animation',
                           '-pix_fmt', 'yuv420p', f'{OUT}/s01_video_mudo.mp4'], stdin=subprocess.PIPE)
    keys = {0, N // 4, N // 2, 3 * N // 4, N - 1}
    for f in range(N):
        fr = render(f); ff.stdin.write(fr.tobytes())
        if f in keys: Image.fromarray(fr).save(f'{OUT}/keyframes/s01_f{f:04d}.png')
        if f % 24 == 0: print('frame', f, '/', N, flush=True)
    ff.stdin.close(); ff.wait()
    json.dump(cues, open(f'{OUT}/s01_cues.json', 'w'))
    print('ok')
